#include "H/Function_Init.H"

//Communication mode selection:
#define  Uart1   0
#define  TWI1    1
#define  SPI1    2

#define  SSI1_Mode  TWI1

void Uart1_Init(uint Freq,unsigned long int baud);
void TWI1_Init(void);
void SPI1_Init(void);

bit Uart1SendFlag = 0;    //Uart1 send interrupt flag
bit Uart1ReceiveFlag = 0; //Uart1 receive interrupt flag
bit SPI1Flag = 0;         //SPI1 data transfer completion flag 
bit TWI1Flag = 0;         //TWI1 interrupt flag

/*****************************************************
*function: void SSI1_Test(void)
*brief: Test SSI1
*param: void
*retval: void
*****************************************************/
void SSI1_Test(void)
{
#if (SSI1_Mode == Uart1)
	Uart1_Init(32,9600);
	while(1)
	{
		US1CON3 = 0xAA;
		while(!Uart1SendFlag);
		Uart1SendFlag = 0;
	}
#endif
	
#if (SSI1_Mode == TWI1)
	TWI1_Init();
	while(1)
	{
		US1CON1 |= 0x20;    //Generate start signal
		while(!TWI1Flag);
        TWI1Flag = 0;		
		US1CON3 = 0x10;	    //Send address and read command
        while(!TWI1Flag);
        TWI1Flag = 0;
        US1CON3 = 0x55;	    //Send data
        while(!TWI1Flag);
        TWI1Flag = 0;
		Delay(100);
		US1CON1 |= 0x10;
		Delay(100);
	}
#endif

#if (SSI1_Mode == SPI1)
	SPI1_Init();
	while(1)
	{
		US1CON2 = 0xAA;
		while(!SPI1Flag);
		SPI1Flag = 0;
        Delay(1000);
	}
#endif	
}

/*****************************************************
*function: void Uart1_Init(uint Freq,unsigned long int baud)
*brief: Uart1 initialization
*param1: Freq
*param2: baud
*retval: void
*****************************************************/
void Uart1_Init(uint Freq,unsigned long int baud)
{
	P1CON &= 0xF5;    //TX/RX is set to pull-up Input Mode 
	P1PH  |= 0x0A;
	
	OTCON |= 0xC0;    //SSI1 Serial interface select UART mode
	US1CON0 = 0x50;   //Set the communication mode to mode 1 and allow receiving
	US1CON1 = Freq*1000000/baud;   
	US1CON2 = (Freq*1000000/baud)>>8;   
	IE2 |= 0x01;      //Enable SSI0 interrupt
    EA = 1;	
}

/*****************************************************
*function: void TWI1_Init(void)
*brief: TWI1 initialization
*param: void
*retval: void
*****************************************************/
void TWI1_Init(void)
{
	OTCON |= 0x80;   //SSI1 Serial interface select TWI mode
	US1CON0 = 0x80;  //Main mode and enable answer enable bit
	US1CON1 = 0x05;  //---- xxxx x:communication rate setting
	IE2 |= 0x01;
	EA = 1;
}

/*****************************************************
*function: void SPI1_Init(void)
*brief: SPI1 initialization
*param: void
*retval: void
*****************************************************/
void SPI1_Init(void)
{
	OTCON |= 0X40;    //SSI1 Serial interface select SPI mode
	US1CON0 = 0x3F;   //SPI is master device. SCK is high in idle state. Collect data on the second edge of the SCK cycle. Set the clock rate to fsys/128
	US1CON1 = 0x00;   //MSB is sent first.  8-bit mode
	US1CON0 |= 0x80;  //Enable SPI1
	IE2 |= 0x01;
	EA = 1;
}

/*****************************************************
*function: void TWI1/SPI/UART1_Int() interrupt 7
*brief: Interrupt service function
*param: void
*retval: void
*****************************************************/
#if (SSI1_Mode == Uart1)
void Uart1_Int() interrupt 15   //Uart1 interrupt service function
{
	if(US1CON0&0x02)    //Judge send flag
	{
		US1CON0 &= 0xFD;
		Uart1SendFlag = 1;
	}
	if((US1CON0&0x01))  //Judge receive flag
	{
		US1CON0 &= 0xFE;
		Uart1ReceiveFlag = 1;
	}	
}
#endif

#if (SSI1_Mode == TWI1)
void TWI1_Int() interrupt 15     //TWI1 interrupt service function
{
	if(US1CON0&0x40)
	{
		US1CON0 &= 0xbf;  //Clear interrupt flag
		TWI1Flag = 1;
	}	
}
#endif 

#if (SSI1_Mode == SPI1)
void SpiInt(void) interrupt 15    //SPI1 interrupt service function
{	  
	if(US1CON1&0X80)    //Judge data transmission flag
	{
		US1CON1 &= ~0X80;
		SPI1Flag = 1;
	}
}
#endif 