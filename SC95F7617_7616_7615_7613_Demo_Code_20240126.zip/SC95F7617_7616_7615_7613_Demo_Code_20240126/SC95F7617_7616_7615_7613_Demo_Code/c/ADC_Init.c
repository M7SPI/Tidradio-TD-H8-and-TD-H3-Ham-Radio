#include "H/Function_Init.H"

void ADC_Init(uint Channel);
unsigned int ADCValue = 0x0000;
unsigned int ADC_AverageValue(void);
bit AdcFlag = 0;

/***********ADC Input Selection*************/
#if (IC_MODEL == SC95F7617 || IC_MODEL == SC95F7616)
	enum Channel {AIN0=0,AIN1,AIN2,AIN3,AIN4,AIN5,AIN6,AIN7,AIN8,AIN9,AIN10,AIN11,AIN12,AIN13,AIN14,AIN15,VDD4=31};
#endif

#if (IC_MODEL == SC95F7615 || IC_MODEL == SC95F7613)
enum Channel {AIN4=4,AIN5,AIN6,AIN7,AIN12=12,AIN13,AIN14,AIN15,VDD4=31};
#endif
	
/*****************************************************
*function: void ADC_Test(void)
*brief: Test ADC
*param: void
*retval: void
*****************************************************/
void ADC_Test(void)
{
	ADC_Init(AIN4);
	while(1)
	{
		 ADCValue = ADC_AverageValue();	
	}
}

/*****************************************************
*function: void ADC_Init(uint Channel)
*brief: ADC initialization
*param: Channel
*retval: void
*****************************************************/
void ADC_Init(uint Channel)
{
	ADCCON = 0X80|Channel;		//Enable ADC; Selective sampling port
	if(Channel<8)
	{
		ADCCFG0 = 1<<Channel;   //Set channel as the sampling port
	}
	else
	{
		ADCCFG1 = 1<<(Channel-8);   //Set channel as the sampling port
	}
	ADCCFG2 = 0x10;			//The sampling time is 3 system clocks
	IE |= 0X40;        //Enable ADC interrupt
	EA = 1;
}


unsigned int ADC_AverageValue()
{
	int i = 0; 
	unsigned int ADC_ValueSum = 0, ADC_ValueMax = 0 ,ADC_ValueMin = 0x01 << 12 ,ADC_ValueMean = 0 ,ADC_ValueTad = 0;
	for(i=0;i<10;i++ )
	{	
		ADCCON |= 0X40;   //Start ADC conversion
	  while(!AdcFlag);	         		 //Wait for the ADC conversion to complete
		AdcFlag = 0;
		ADC_ValueTad = (ADCVH<<4)+(ADCVL>>4);
		if(ADC_ValueTad>ADC_ValueMax)
		{
		 ADC_ValueMax = ADC_ValueTad;
		}
		if(ADC_ValueTad<ADC_ValueMin)
		{
		 ADC_ValueMin = ADC_ValueTad;
		}
		ADC_ValueSum += ADC_ValueTad;
	}
	ADC_ValueMean = (unsigned int)((ADC_ValueSum - ADC_ValueMax - ADC_ValueMin) / 8);
  return ADC_ValueMean;
}



void ADC_Interrupt(void) interrupt 6
{
	ADCCON &= ~(0X20);  //clear flag bit
	AdcFlag = 1;
}