#include "H/Function_Init.H"

//Communication mode selection:
#define  Uart0   0
#define  TWI0    1
#define  SPI0    2

#define  SSI0_Mode  Uart0

void Uart0_Init(uint Freq,unsigned long int baud);
void TWI0_Init(void);
void SPI0_Init(void);

bit Uart0SendFlag = 0;    //Uart0 send interrupt flag
bit Uart0ReceiveFlag = 0; //Uart0 receive interrupt flag
bit SPI0Flag = 0;         //SPI0 data transfer completion flag
bit TWI0Flag = 0;         //TWI0 interrupt flag

/*****************************************************
*function: void SSI0_Test(void)
*brief: Test SSI0
*param: void
*retval: void
*****************************************************/
void SSI0_Test(void)
{
#if (SSI0_Mode == Uart0)
	Uart0_Init(32,9600);
	while(1)
	{
		US0CON3 = 0xAA;
		while(!Uart0SendFlag);
		Uart0SendFlag = 0;
	}
#endif
	
#if (SSI0_Mode == TWI0)
	TWI0_Init();
	while(1)
	{
		US0CON1 |= 0x20;    //Generate start signal
		while(!TWI0Flag);
    TWI0Flag = 0;		
		US0CON3 = 0x10;	    //Send address and read command
		while(!TWI0Flag);
		TWI0Flag = 0;
		US0CON3 = 0x55;	    //Send data
		while(!TWI0Flag);
		TWI0Flag = 0;
		Delay(100);
		US0CON1 |= 0x10;
		Delay(100);
	}
#endif

#if (SSI0_Mode == SPI0)
	SPI0_Init();
	while(1)
	{
		US0CON2 = 0xAA;
		while(!SPI0Flag);
		SPI0Flag = 0;
        Delay(1000);
	}
#endif	
}

/*****************************************************
*function: void Uart0_Init(uint Freq,unsigned long int baud)
*brief: Uart0 initialization
*param1: Freq
*param2: baud
*retval: void
*****************************************************/
void Uart0_Init(uint Freq,unsigned long int baud)
{
	P0CON &= 0x9F;    //TX/RX is set to pull-up Input Mode 
	P0PH  |= 0x60;
	
	OTCON |= 0x30;    //SSI0 Serial interface select UART mode
	US0CON0 = 0x50;   //Set the communication mode to mode 1 and allow receiving
	US0CON1 = Freq*1000000/baud;   
	US0CON2 = (Freq*1000000/baud)>>8;   
	IE1 |= 0x01;      //Enable SSI0 interrupt
  EA = 1;	
}

/*****************************************************
*function: void TWI0_Init(void)
*brief: TWI0 initialization
*param: void
*retval: void
*****************************************************/
void TWI0_Init(void)
{
	OTCON |= 0x20;   //SSI0 Serial interface select TWI mode
	US0CON0 = 0x80;  //Main mode and enable answer enable bit
	US0CON1 = 0x05;  //---- xxxx x:communication rate setting
	IE1 |= 0x01;
	EA = 1;
}

/*****************************************************
*function: void SPI0_Init(void)
*brief: SPI0 initialization
*param: void
*retval: void
*****************************************************/
void SPI0_Init(void)
{
	OTCON |= 0X10;    //SSI0 Serial interface select SPI mode
	US0CON0 = 0x3F;   //SPI is master device. SCK is high in idle state. Collect data on the second edge of the SCK cycle. Set the clock rate to fsys/128
	US0CON1 = 0x00;   //MSB is sent first.  8-bit mode
	US0CON0 |= 0x80;  //Enable SPI0
	IE1 |= 0x01;
	EA = 1;
}

/*****************************************************
*function: void TWI0/SPI/UART0_Int() interrupt 7
*brief: Interrupt service function
*param: void
*retval: void
*****************************************************/
#if (SSI0_Mode == Uart0)
void Uart0_Int() interrupt 7   //Uart0 interrupt service function
{
	if(US0CON0&0x02)    //Judge send flag
	{
		US0CON0 &= 0xFD;
		Uart0SendFlag = 1;
	}
	if((US0CON0&0x01))  //Judge receive flag
	{
		US0CON0 &= 0xFE;
		Uart0ReceiveFlag = 1;
	}	
}
#endif

#if (SSI0_Mode == TWI0)
void TWI0_Int() interrupt 7     //TWI0 interrupt service function
{
	if(US0CON0&0x40)
	{
		US0CON0 &= 0xbf;  //Clear interrupt flag
		TWI0Flag = 1;
	}	
}
#endif 

#if (SSI0_Mode == SPI0)
void SpiInt(void) interrupt 7    //SPI0 interrupt service function
{	  
	if(US0CON1&0X80)    //Judge data transmission flag
	{
		US0CON1 &= ~0X80;
		SPI0Flag = 1;
	}
}
#endif 