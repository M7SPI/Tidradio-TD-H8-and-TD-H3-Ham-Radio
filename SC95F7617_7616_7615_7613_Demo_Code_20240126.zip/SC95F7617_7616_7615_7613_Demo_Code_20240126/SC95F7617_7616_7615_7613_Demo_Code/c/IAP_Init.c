#include "H/Function_Init.H"

unsigned char code *IapAddr = 0x00;

void IAPWrite(uint Addr,uchar Value);
void IAPPageErase(uint Addr);
uchar IAPRead(uint Addr);
uchar IapReadData = 0x00;   //Store data read by IAP

/*****************************************************
*function: void IAP_Test(uint Address)
*brief: Test IAP
*param: Address
*retval: void
*****************************************************/
void IAP_Test(uint Address)
{
    IAPPageErase(Address);   //Sector Erase
	IAPWrite(Address,0xff);    //Write Data
	IapReadData = IAPRead(Address);
	while(1)
	{
		if(IapReadData == 0xff)
		{
			P02 = ~P02;
		}
		else
		{
			P03 = ~P03;
		}
	}
}

/*****************************************************
*function: void IAPWrite(uint Addr,uchar Value)
*brief: IAP write operation
*param1: Addr
*param2: Value
*retval: void
*****************************************************/
void IAPWrite(uint Addr,uchar Value)
{	
  bit temp = EA;
	EA = 0;
  IAPADE = 0x00;   
	IAPDAT = Value;     //Write data
	IAPADH = (unsigned char)((Addr >> 8));   //IAP writes the high 8 bits of the address
	IAPADL = (unsigned char)Addr;            //IAP writes the low 8 bits of the address
	IAPKEY = 0xF0;		  //Open IAP function and operation time limit setting
  IAPCTL = 0X10;      //Enter the Flash ROM write operation
	IAPCTL |= 0x02;     //Perform write or sector erase operation commands
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
  _nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	IAPADE = 0x00;      //MOVC pointing to the ROM
	EA = temp;
}

/*****************************************************
*function: void IAPPageErase(uint Addr)
*brief: The specified sector of Flash ROM will be erased
*param: Addr
*retval: void
*****************************************************/
void IAPPageErase(uint Addr)
{
	bit temp = EA;
	EA = 0;
	IAPADE = 0x00;
	
	IAPADH = (unsigned char)((Addr >> 8)); //Erases the high 8 bits of the first address
  IAPADL = (unsigned char)Addr;          //Erases the low 8 bits of the first address
	
	IAPKEY = 0XF0;
	IAPCTL = 0X20;
	IAPCTL |= 0X02;
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
  _nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	IAPADE = 0x00;
	EA = temp;		
}

/*****************************************************
*function: uchar IAPRead(uint Addr)
*brief: IAP read data
*param: Addr
*retval: ReadValue-Read the data
*****************************************************/
uchar IAPRead(uint Addr)
{
	uchar ReadValue = 0x00;
  bit temp = EA;
	EA = 0;
	IAPADE = 0x00;
	ReadValue = *(IapAddr+Addr); //Read the data
	IAPADE = 0x00;               //MOVC pointing to the ROM
	EA = temp;
	return ReadValue;
}
