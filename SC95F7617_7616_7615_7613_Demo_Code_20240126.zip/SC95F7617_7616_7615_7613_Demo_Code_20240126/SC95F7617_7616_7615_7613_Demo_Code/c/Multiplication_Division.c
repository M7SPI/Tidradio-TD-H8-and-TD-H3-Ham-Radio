#include "H/Function_Init.H"

u32 product = 0;//product
u32 quotient = 0;//quotient
u16 remainder = 0;//remainder
Result_union result;

void Multiplier_Divider_Test(void)
{
	while(1)
	{		
		//MDU
		Multiplication(0x55AA, 0xAA55);  //Multiplication calculation
		if(product == 0x38ff5572)   //Judge product
		{
			P04 = 0;
		}
		
		Division(0xFFAA5500,0xAA55);    //Division calculation
		if(quotient == 0x18040 && remainder == 0x3FC0)  //Judge quotient and remainder
		{
			P04 = 1;
		}
	}		
}

/*****************************************************
*function: void Multiplication(u16 faciend, u16 Multiplier)
*brief: Multiplication
*param1: faciend
*param2: Multiplier
*retval: void
*****************************************************/
void Multiplication(u16 faciend, u16 Multiplier)
{
  OPERCON &= ~0x40;   //Multiplication
    
	EXA0 = faciend;
	EXA1 = faciend>>8;
	EXBL = Multiplier;
	EXBH = Multiplier>>8;

	OPERCON |= 0x80;      //Begin to calculate
	while(OPERCON & 0x80);

	result.reg.a0 = EXA0;
	result.reg.a1 = EXA1;
	result.reg.a2 = EXA2;
	result.reg.a3 = EXA3;

	product = result.Result;
}	

/*****************************************************
*function: void Division(u32 dividend,u16 divisor)
*brief: Multiplication
*param1: dividend
*param2: divisor
*retval: void
*****************************************************/
void Division(u32 dividend,u16 divisor)
{
	Result_union temp;
	temp.Result = dividend;

    OPERCON &= ~0x40;
    OPERCON |= 0x40;    //Division
    
	EXA0 = temp.reg.a0;
	EXA1 = temp.reg.a1;
	EXA2 = temp.reg.a2;
	EXA3 = temp.reg.a3;

	EXBL = divisor;
	EXBH = divisor>>8;

	OPERCON |= 0xC0;      //Begin to calculate
	while(OPERCON & 0x80);

	result.reg.a0 = EXA0;
	result.reg.a1 = EXA1;
	result.reg.a2 = EXA2;
	result.reg.a3 = EXA3;

	remainder = EXBH*256+ EXBL;
	quotient  = result.Result;
}

