#include "H/Function_Init.H"

void Timer_Init(void);
uint count = 0;
uint count1=0,count2=0;
uchar flag=0;

/*****************************************************
*function: void Timer_Test(void)
*brief: Test T0/1/2
*param: void
*retval: void
*****************************************************/
void Timer_Test(void)
{
	Timer_Init();
	while(1)
	{
	}
}

/*****************************************************
*function: void Timer_Init(void)
*brief: T0/1/2 initialization
*param: void
*retval: void
*****************************************************/
void Timer_Init(void)
{ 
	TMCON = 0X03;    //-------11 ;T0/T1 input frequency selection control
	
	//T0 setting
	TMOD |= 0x01;                 //0000 0001;Timer/Counter 0 mode selection: Mode 1
	TL0 = (65536 - 16000)%256;    //The clock is Fsys��OVERFLOW TIME = 16000*(1/Fsys):
	TH0 = (65536 - 16000)/256;
	TR0 = 0;
	ET0 = 1;//Enable Timer0 interrupt
	TR0 = 1;//Allowed Timer0 to start counting
    
	//T1 setting
	TMOD |= 0x20;            //0010 0000; Timer/Counter 1 mode selection: Mode 2
	TL1 = 256 - 160;         //The clock is Fsys��OVERFLOW TIME = 160*(1/Fsys):
	TH1 = 256 - 160;
	TR1 = 0;
	ET1 = 1;//Enable Timer1 interrupt
	TR1 = 1;//Allowed Timer1 to start counting
    
	//T2 setting
	TXINX = 0x02;   //Select Timer2
	TXCON = 0X09;   //Enable EXT2,16 bit capture mode
	TXMOD = 0X80;
	THX = 0X00;
	TLX = 0X00;
	RCAPXH = 0X00;
	RCAPXL = 0X00;
  ET2 = 1;  //Enable Timer2 interrupt
	TRX = 1;  //Allowed Timer2 to start counting

	//T3 setting
  TXINX = 0x03;  //Select Timer3
	TXMOD = 0x80;    
	TXCON = 0x00;	 //set to 16-bit timer/counter with reload function
	RCAPXH = (65536-16000)/256;   //The clock is Fsys��OVERFLOW TIME = 16000*(1/Fsys):
	RCAPXL = (65536-16000)%256;
	TRX = 0;
	IE1 |= 0x40; //Enable Timer3 interrupt
  IP1 |= 0X40;
	TRX = 1;     //Allowed Timer3 to start counting
    
  //T4 setting
  TXINX = 0x04;  //Select Timer4
	TXMOD = 0x80;    
	TXCON = 0x00;	 //set to 16-bit timer/counter with reload function
	RCAPXH = (65536-32000)/256;     //The clock is Fsys��OVERFLOW TIME = 32000*(1/Fsys):
	RCAPXL = (65536-32000)%256;
	TRX = 0;
	IE1 |= 0x80;   //Enable Timer3 interrupt
  IP1 |= 0X80;
	TRX = 1;       //Allowed Timer4 to start counting
    
	EA = 1;	
}

/*****************************************************
*function: void timer0/1/2/3/4() interrupt 1/3/5/13/14
*brief: Interrupt service function
*param: void
*retval: void
*****************************************************/
void timer0() interrupt 1
{
  TL0 = (65536 - 16000)%256;
	TH0 = (65536 - 16000)/256;
	P02 = ~P02;	
}

void timer1() interrupt 3
{
	P03 = ~P03;
}

void Timer2Int(void) interrupt 5
{		
  TXINX = 0x02;            //Select Timer2
  if((TXCON & 0x40))
	{
    P07 = ~P07;
		TXCON &= ~0X40;      //Clear flag bit
		if(++flag >= 12)     
		{
			flag = 0;
			THX = 0;
			TLX = 0;
		}
		if(flag == 10)      
		{
			count1 = ((uint)(RCAPXH << 8) + RCAPXL);
		}
		if(flag == 11)
		{
			count2 = ((uint)(RCAPXH << 8) + RCAPXL);
			count = count2 - count1;      //The value from the 10th falling edge to the 11th falling edge
		}
	}
}

void Timer3Int(void) interrupt 13
{		
  TXINX = 0x03;   //Select Timer3
	TFX = 0;        //Overflow clearing
  P05 = ~P05;
}

void Timer4Int(void) interrupt 14
{		
  TXINX = 0x04;   //Select Timer4
	TFX = 0;        //Overflow clearing
  P06 = ~P06;
}
