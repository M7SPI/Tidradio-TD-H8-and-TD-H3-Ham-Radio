#include "H/Function_Init.H"

void BTM_Init(void);

/*****************************************************
*function: void BTM_Test(void)
*brief: Test BTM
*param: void
*retval: void
*****************************************************/
void BTM_Test(void)
{
	BTM_Init();
	while(1)
	{
	}
}

/*****************************************************
*function: void BTM_Init(void)
*brief: BTM initialization
*param: void
*retval: void
*****************************************************/
void BTM_Init(void)
{
//	BTMCON = 0x00;  //Disable
//	BTMCON = 0x80;  //An interrupt is generated every 15.6ms
//	BTMCON = 0x81;	//An interrupt is generated every 31.3ms
//	BTMCON = 0x82;	//An interrupt is generated every 62.5ms
//	BTMCON = 0x83;	//An interrupt is generated every 125ms
	BTMCON = 0x84;	//An interrupt is generated every 0.25s
//	BTMCON = 0x85;	//An interrupt is generated every 0.5ms
//	BTMCON = 0x86;	//An interrupt is generated every 1s
//	BTMCON = 0x87;	//An interrupt is generated every 2ms
//  BTMCON = 0x88;	//An interrupt is generated every 4s
//  BTMCON = 0x89;	//An interrupt is generated every 8s
//  BTMCON = 0x8A;	//An interrupt is generated every 16s
//  BTMCON = 0x8B;	//An interrupt is generated every 32s
	EA = 1;           //Enable total interrupt
	IE1 |= 0x04;      //Enable BTM interrupt
}

/*****************************************************
*function: void BTM_Int(void) interrupt 9
*brief: Interrupt service function
*param: void
*retval: void
*****************************************************/
void BTM_Int(void) interrupt 9
{
	if(!(BTMCON&0X40))		//Determine the interrupt flag bit
	{
		P05 = ~P05;
	}
}