#include "H/Function_Init.H"
/*****************************************************
*function: void IO_Init(void)
*brief: IO port initialization
*param: void
*retval: void
*****************************************************/
void IO_Init(void)
{
	#if (IC_MODEL == SC95F7617)  //SC92F8617 pin definition
	P0CON = 0xFF;  //Set P0 to strong push-pull output mode
	P0PH  = 0x00;
	P1CON = 0x00;  //Set P1 to high-impedance input mode
	P1PH  = 0x00;
	P2CON = 0x00;  //Set P2 to pull-up Input Mode 
	P2PH  = 0xFF;
	P3CON = 0xFF;  //Set P3 to strong push-pull output mode
	P3PH  = 0x00;
	P4CON = 0xFF;  //Set P4 to strong push-pull output mode
	P4PH  = 0x00;
	P5CON = 0xFF;  //Set P5 to strong push-pull output mode
	P5PH  = 0x00;
	#endif
	
	#if (IC_MODEL == SC95F7616)  //SC92F8616 pin definition
	P0CON = 0xFF;  //Set P0 to strong push-pull output mode
	P0PH  = 0x00;
	P1CON = 0x00;  //Set P1 to high-impedance input mode
	P1PH  = 0x00;
	P2CON = 0x00;  //Set P2 to pull-up Input Mode 
	P2PH  = 0xFF;
	P3CON = 0xFF;  //Set P3 to strong push-pull output mode
	P3PH  = 0x00;
	P4CON = 0xFF;  //Set P4 to strong push-pull output mode
	P4PH  = 0x00;
	P5CON = 0xFF;  //Set P5 to strong push-pull output mode
	P5PH  = 0x00;
	SC95F7616_NIO_Init(); //Function that does not elicit a pin
	#endif
    
	#if (IC_MODEL == SC95F7615)  //SC92F8615 pin definition
	P0CON = 0xFF;  //Set P0 to strong push-pull output mode
	P0PH  = 0x00;
	P1CON = 0x00;  //Set P1 to high-impedance input mode
	P1PH  = 0x00;
	P2CON = 0x00;  //Set P2 to pull-up Input Mode 
	P2PH  = 0xFF;
	P3CON = 0xFF;  //Set P3 to strong push-pull output mode
	P3PH  = 0x00;
	P4CON = 0xFF;  //Set P4 to strong push-pull output mode
	P4PH  = 0x00;
	P5CON = 0xFF;  //Set P5 to strong push-pull output mode
	P5PH  = 0x00;
	SC95F7615_NIO_Init(); //Function that does not elicit a pin
	#endif
	
	#if (IC_MODEL == SC95F7613)  //SC92F8613 pin definition
	P0CON = 0xFF;  //Set P0 to strong push-pull output mode
	P0PH  = 0x00;
	P1CON = 0x00;  //Set P1 to high-impedance input mode
	P1PH  = 0x00;
	P2CON = 0x00;  //Set P2 to pull-up Input Mode 
	P2PH  = 0xFF;
	P3CON = 0xFF;  //Set P3 to strong push-pull output mode
	P3PH  = 0x00;
	P4CON = 0xFF;  //Set P4 to strong push-pull output mode
	P4PH  = 0x00;
	SC95F7613_NIO_Init(); //Function that does not elicit a pin
	#endif
}

void Delay(uint time)
{
    for(;time>0;time--);
}