#include "H/Function_Init.H" 

void Uart_Init(uint Freq,unsigned long int baud);
uint UART_RxData[5];
bit UartSendFlag = 0; //Send interrupt flag bit
bit UartReceiveFlag = 0; //Receive interrupt flag bit

/*****************************************************
*function: void Uart_Test(void)
*brief: Test Uart
*param: void
*retval: void
*****************************************************/
void Uart_Test(void)
{
  int num1,num2;
	Uart_Init(32,9600);
	while(1)
	{
		for(num1=0;num1<5;num1++)
		{
			while(!UartReceiveFlag);
			UartReceiveFlag = 0;
			UART_RxData[num1] = SBUF;
		}
		for(num2=0;num2<5;num2++)
		{
			SBUF = UART_RxData[num2];
			while(!UartSendFlag);
			UartSendFlag = 0;
		}

		Delay(1000);
	}
}

/*****************************************************
*function: void Uart_Init(uint Freq,unsigned long int baud)
*brief: Uart initialization-select Timer1 to be the baud rate generator
*param1: Freq
*param2: baud
*retval: void
*****************************************************/
void Uart_Init(uint Freq,unsigned long int baud)    
{
	P2CON &= 0xFC;   //TX/RX is set to pull-up Input Mode 
	P2PH  |= 0x03;
	
	SCON  |= 0X50;   //Set the communication mode to mode 1 and allow receiving
	TMCON |= 0X02;   //T1Ƶ��Դ����fsys
	TXINX = 0x02;    //ָ��ʱ��2
	TXCON = 0X00;    //UART0ʱ����ԴΪ��ʱ��1
	TH1 = (Freq*1000000/baud)>>8;
	TL1 = Freq*1000000/baud;
	TR1 = 0;
	ET1 = 0;
	EUART = 1;     //Enable UART interrupt
	EA = 1;
}

/*****************************************************
*function: void Uart_Init(uint Freq,unsigned long int baud) 
*brief: Uart initialization-select Timer2 to be the baud rate generator
*param1: Freq
*param2: baud
*retval: void
*****************************************************
void Uart_Init(uint Freq,unsigned long int baud)   
{
	P2CON &= 0xFC;   //TX/RX is set to pull-up Input Mode 
	P2PH  |= 0x03;

	SCON  |= 0X50;   //Set the communication mode to mode 1 and allow receiving
  TXINX = 0x02;
	TMCON |= 0X04;
	TXMOD = 0X00;
	TXCON = 0X30;
	RCAPXH = Freq*1000000/baud/256;
	RCAPXL = Freq*1000000/baud%256;
	TRX = 0;
	ET2 = 0;
	EUART = 1;     //Enable UART interrupt
	EA = 1;
}
*/

/*****************************************************
*function: void UartInt(void) interrupt 4
*brief: Interrupt service function
*param: void
*retval: void
*****************************************************/
void UartInt(void) interrupt 4
{
	if(TI)
	{
		TI = 0;	
		UartSendFlag = 1;		
	}
	if(RI)
	{
		RI = 0;	
		UartReceiveFlag = 1;
	}	
}
