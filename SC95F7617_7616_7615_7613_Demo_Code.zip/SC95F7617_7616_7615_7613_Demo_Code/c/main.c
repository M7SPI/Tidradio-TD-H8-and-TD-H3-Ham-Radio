#include "H/Function_Init.H"
  
/**************************************************************
Description:
1. Options for Target��Target1����BL51 Locate->Code Range:0x100,In the program option DISJTG please select Normal,reset pin is used as normal IO.
2. Change the definition of TEST to test the corresponding functionality separately
3. attention: Select the test model in the Function.H
4. version: V1.0
***************************************************************/
#define Test  6    //BTM:0 EXTI:1 Timer:2 LCD_LED:3 PWM:4 Uart0:5 USCI0:6 USCI1:7 USCI2:8 ADC:9 IAP:10 Multiplier_Divider:11 CMP:12 CRC:13

void main(void)
{
	IO_Init();
//	WDTCON |= 0x10;		    //clear WDT
	switch(Test)
	{
		case 0: BTM_Test();
		break;
		case 1: EXTI_Test();
		break;
		case 2: Timer_Test();
		break;
		case 3: LCD_LED_Test();
		break;
		case 4: PWM_Test();
		break;
		case 5: Uart_Test();
		break;
		case 6: USCI0_Test();
		break;
    case 7: USCI1_Test();
		break;
    case 8: USCI2_Test();
		break;
		case 9: ADC_Test();
		break;
		case 10: IAP_Test(0xCFFF);   //Test read and write at address 0xCfff
		break;
		case 11: Multiplier_Divider_Test();
		break;
		case 12: CMP_Test();
		break;
    case 13: CRC_Test();
		break;
		default:
		break;
	}
}

	
