#include "H/Function_Init.H"

//Communication mode selection:
#define  Uart1   0
#define  TWI1    1
#define  SPI1    2

#define  USCI1_Mode  SPI1

#define TWI1_Mode 1//0:Master  1��Slaver
#define SPI1_Mode 1 //0:Master  1��Slaver

void Uart1_Init(uint Freq, unsigned long int baud);
void TWI1_Init(void);
void SPI1_Init(void);

bit Uart1SendFlag = 0;   //Uart1 send interrupt flag
bit Uart1ReceiveFlag = 0; //Uart1 receive interrupt flag
bit SPI1Flag = 0;        //SPI1 interrupt flag
bit TWI1Flag = 0;         //TWI1 interrupt flag
uint8_t TxXferCount1 = 0;  
uint8_t RxXferCount1 = 0;  


volatile uint8_t Uart1_RxData[5];

uint8_t SPI1_Master_SendData[8] = {0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08};
volatile uint8_t SPI1_Slaver_ReceiveData[8];

uint8_t TWI1_Master_SendData[8]={0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08};
volatile uint8_t TWI1_Slaver_ReceiveData[8];
/*****************************************************
*function: void USCI1_Test(void)
*brief: Test USCI1
*param: void
*retval: void
*****************************************************/
void USCI1_Test(void)
{
#if (USCI1_Mode == Uart1)
		int num1,num2;
	Uart1_Init(32,9600);
		while(1)
		{
			for(num1=0;num1<5;num1++)
			{
				while(!Uart1ReceiveFlag);
				Uart1ReceiveFlag = 0;
				Uart1_RxData[num1] = US1CON3 ;
			}
			for(num2=0;num2<5;num2++)
			{
				US1CON3  = Uart1_RxData[num2];
				while(!Uart1SendFlag);
				Uart1SendFlag = 0;
			}
		
  }
#endif
	
#if (USCI1_Mode == TWI1)
  TWI1_Init();
  while(1)
  {
#if (TWI1_Mode == 0)  //Master
		  US1CON1 |= 0x20;     //Origin condition
		  Delay(100);
      while(TWI1Flag == 0);
      TWI1Flag = 0; 
      US1CON3 = 0x02;	     //Send address and write command
      while(TWI1Flag == 0);
      TWI1Flag = 0; 
      while(TxXferCount1 < 8)
			{
				US1CON3 = TWI1_Master_SendData[TxXferCount1];    //TWI Send data
				while(TWI1Flag == 0);
				TWI1Flag = 0; 
			  TxXferCount1++;
			}
     TxXferCount1=0;

      /* Whether the transmission is complete or not, the end signal needs to be sent to prevent the host from occupying the bus */

      US1CON1 |= 0x10;
	
			Delay(1000);
#endif   
#if (TWI1_Mode == 1)  //Slaver 

      while((0x07 & US1CON0)!=0x02);//Check that the status is received
			Delay(100);
			while(TWI1Flag == 0);
			TWI1Flag = 0;                 
     	Delay(100);
  
			do
			{
				if(RxXferCount1 == 7) US1CON0 &= 0XF7;   //AA enable bit, return to the UAC of the host
				while(TWI1Flag == 0);
				TWI1Flag = 0;  
				TWI1_Slaver_ReceiveData[RxXferCount1] = US1CON3;             //TWI Received data
				RxXferCount1++; 
			}  while(RxXferCount1 < 8);

			US1CON0 |= 0X08; //AA Enable bit
			RxXferCount1 =0;
			while((0x07 & US1CON0)!=0x00);
  
		
#endif
		}
#endif
		
#if (USCI1_Mode == SPI1)
  SPI1_Init();
	
			while(1)
			{
#if (SPI1_Mode == 0)  //Master
				TxXferCount1 = 0;
				while(TxXferCount1 <  8)//Determines whether to accept all data
				{
				 
					US1CON2 = SPI1_Master_SendData[TxXferCount1];
					while(SPI1Flag == 0);	//Wait for sending to complete	   
					SPI1Flag = 0;		
					TxXferCount1 ++;	
				}
				Delay(1000);
#endif
#if (SPI1_Mode == 1)  //Slaver
			while(RxXferCount1 <8)
				{
						/* Wait for the SPI interrupt flag position to start */
					while(SPI1Flag == 0);	//Wait for sending to complete
					SPI1Flag = 0;		
					SPI1_Slaver_ReceiveData[RxXferCount1] = US1CON2;		
					RxXferCount1++;
				}
				RxXferCount1 = 0;
				Delay(100);

#endif
		
 
  }
#endif
}
/*****************************************************
*function: void Uart1_Init(uint Freq,unsigned long int baud)
*brief: Uart1 initialization
*param1: Freq
*param2: baud
*retval: void
*****************************************************/
void Uart1_Init(uint Freq,unsigned long int baud)
{
	P1CON &= 0xF5;    //TX/RX is set to pull-up Input Mode 
	P1PH  |= 0x0A;
	
	OTCON |= 0xC0;    //USCI1 Serial interface select UART mode
	US1CON0 = 0x50;   //Set the communication mode to mode 1 and allow receiving
	US1CON1 = Freq*1000000/baud;   
	US1CON2 = (Freq*1000000/baud)>>8;   
	IE2 |= 0x01;      //Enable USCI0 interrupt
    EA = 1;	
}

/*****************************************************
*function: void TWI1_Init(void)
*brief: TWI1 initialization
*param: void
*retval: void
*****************************************************/
void TWI1_Init(void)
{
  OTCON |= 0x80;   //USCI1 Serial interface select TWI mode
  US1CON0 = 0x88;  //The reply flag bit was enabled
  US1CON1 = 0x40;  //---- xxxx  x is Clock rate
  US1CON2 = 0x02;  //Slave address 0x01
  IE2 |= 0x01;
  EA = 1;
}

/*****************************************************
*function: void SPI1_Init(void)
*brief: SPI1 initialization
*param: void
*retval: void
*****************************************************/
void SPI1_Init(void)
{
   OTCON |= 0X40;    //USCI1 Serial interface select SPI mode
#if (SPI1_Mode == 0)	
 {  US1CON0 = 0x23;   }   //Set SPI1 as the master, SCK to low level, SCK cycle first edge to collect data, the clock rate to Fsy/8
#elif (SPI1_Mode == 1)	
 {  US1CON0 = 0x03;   }   //Set SPI1 to slave , SCK idle time to low, SCK cycle first edge to collect data,the clock rate to Fsy/8
#endif 
  US1CON1 = 0x01;   //MSB is sent first.  8-bit mode
  US1CON0 |= 0x80;  //Enable SPI1
  IE2 |= 0x01;
  EA = 1;
}

/*****************************************************
*function: void TWI1/SPI/UART1_Int() interrupt 7
*brief: Interrupt service function
*param: void
*retval: void
*****************************************************/
#if (USCI1_Mode == Uart1)
void Uart1_Int() interrupt 15   //Uart1 interrupt service function
{
	if(US1CON0&0x02)    //Judge send flag
	{
		US1CON0 &= 0xFD;
		Uart1SendFlag = 1;
	}
	if((US1CON0&0x01))  //Judge receive flag
	{
		US1CON0 &= 0xFE;
		Uart1ReceiveFlag = 1;
	}	
}
#endif

#if (USCI1_Mode == TWI1)
void TWI1_Int() interrupt 15     //TWI1 interrupt service function
{
	if(US1CON0&0x40)
	{
		US1CON0 &= 0xbf;  //Clear interrupt flag
		TWI1Flag = 1;
	}	
}
#endif 

#if (USCI1_Mode == SPI1)
void Spi1Int(void) interrupt 15    //SPI1 interrupt service function
{	  
	if(US1CON1&0X80)    //Judge data transmiUSCIon flag
	{
		US1CON1 &= ~0X80;
		SPI1Flag = 1;
	}
}
#endif 