#include "H/Function_Init.H"

//Communication mode selection:
#define  Uart2   0
#define  TWI2    1
#define  SPI2    2

#define  SSI2_Mode  TWI2

void Uart2_Init(uint Freq,unsigned long int baud);
void TWI2_Init(void);
void SPI2_Init(void);

bit Uart2SendFlag = 0;    //Uart2 send interrupt flag
bit Uart2ReceiveFlag = 0; //Uart2 receive interrupt flag
bit SPI2Flag = 0;         //SPI2 data transfer completion flag 
bit TWI2Flag = 0;         //TWI2 interrupt flag

/*****************************************************
*function: void SSI2_Test(void)
*brief: Test SSI2
*param: void
*retval: void
*****************************************************/
void SSI2_Test(void)
{
#if (SSI2_Mode == Uart2)
	Uart2_Init(32,9600);
	while(1)
	{
		US2CON3 = 0xAA;
		while(!Uart2SendFlag);
		Uart2SendFlag = 0;
	}
#endif
	
#if (SSI2_Mode == TWI2)
	TWI2_Init();
	while(1)
	{
		US2CON1 |= 0x20;    //Generate start signal
		while(!TWI2Flag);
        TWI2Flag = 0;		
		US2CON3 = 0x10;	    //Send address and read command
        while(!TWI2Flag);
        TWI2Flag = 0;
        US2CON3 = 0x55;	    //Send data
        while(!TWI2Flag);
        TWI2Flag = 0;
		Delay(100);
		US2CON1 |= 0x10;
		Delay(100);
	}
#endif

#if (SSI2_Mode == SPI2)
	SPI2_Init();
	while(1)
	{
		US2CON2 = 0xAA;
		while(!SPI2Flag);
		SPI2Flag = 0;
        Delay(1000);
	}
#endif	
}

/*****************************************************
*function: void Uart2_Init(uint Freq,unsigned long int baud)
*brief: Uart2 initialization
*param1: Freq
*param2: baud
*retval: void
*****************************************************/
void Uart2_Init(uint Freq,unsigned long int baud)
{
	P4CON &= 0xCF;    //TX/RX is set to pull-up Input Mode 
	P4PH  |= 0x30;
	
	TMCON |= 0xC0;    //SSI2 Serial interface select UART mode
	US2CON0 = 0x50;   //Set the communication mode to mode 1 and allow receiving
	US2CON1 = Freq*1000000/baud;   
	US2CON2 = (Freq*1000000/baud)>>8;   
	IE2 |= 0x02;      //Enable SSI0 interrupt
    EA = 1;	
}

/*****************************************************
*function: void TWI2_Init(void)
*brief: TWI2 initialization
*param: void
*retval: void
*****************************************************/
void TWI2_Init(void)
{
	TMCON |= 0x80;   //SSI1 Serial interface select TWI mode
	US2CON0 = 0x80;  //Main mode and enable answer enable bit
	US2CON1 = 0x05;  //---- xxxx x:communication rate setting
	IE2 |= 0x02;
	EA = 1;
}

/*****************************************************
*function: void SPI2_Init(void)
*brief: SPI2 initialization
*param: void
*retval: void
*****************************************************/
void SPI2_Init(void)
{
	TMCON |= 0X40;    //SSI2 Serial interface select SPI mode
	US2CON0 = 0x3F;   //SPI is master device. SCK is high in idle state. Collect data on the second edge of the SCK cycle. Set the clock rate to fsys/128
	US2CON1 = 0x00;   //MSB is sent first.  8-bit mode
	US2CON0 |= 0x80;  //Enable SPI2
	IE2 |= 0x02;
	EA = 1;
}

/*****************************************************
*function: void TWI1/SPI/UART1_Int() interrupt 7
*brief: Interrupt service function
*param: void
*retval: void
*****************************************************/
#if (SSI2_Mode == Uart2)
void Uart2_Int() interrupt 16   //Uart2 interrupt service function
{
	if(US2CON0&0x02)    //Judge send flag
	{
		US2CON0 &= 0xFD;
		Uart2SendFlag = 1;
	}
	if((US2CON0&0x01))  //Judge receive flag
	{
		US2CON0 &= 0xFE;
		Uart2ReceiveFlag = 1;
	}	
}
#endif

#if (SSI2_Mode == TWI2)
void TWI2_Int() interrupt 16     //TWI2 interrupt service function
{
	if(US2CON0&0x40)
	{
		US2CON0 &= 0xbf;  //Clear interrupt flag
		TWI2Flag = 1;
	}	
}
#endif 

#if (SSI2_Mode == SPI2)
void SpiInt(void) interrupt 16    //SPI2 interrupt service function
{	  
	if(US2CON1&0X80)    //Judge data transmission flag
	{
		US2CON1 &= ~0X80;
		SPI2Flag = 1;
	}
}
#endif 