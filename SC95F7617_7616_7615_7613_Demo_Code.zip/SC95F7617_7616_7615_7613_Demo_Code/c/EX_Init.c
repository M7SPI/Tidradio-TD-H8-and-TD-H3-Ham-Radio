#include "H/Function_Init.H"

void EX_Init(void);
uchar INT1_flag = 0x00;

/*****************************************************
*function: void EXTI_Test(void)
*brief: Test External interrupt
*param: void
*retval: void
*****************************************************/
void EXTI_Test(void)
{
	EX_Init();
	while(1)
	{					
	}
}

/*****************************************************
*function: void EX_Init(void)
*brief: External interrupt initialization
*param: void
*retval: void
*****************************************************/
void EX_Init(void)
{	
	//Configuring the I/O Mode: INT07(P07)��INT11/10(P41/40)��INT20/21(P20/21)
	P0CON &= 0X7F;     //Set INTx to Pull-up Input Mode 
	P0PH  |= 0x80;     //
	P4CON &= 0XFC;     //Set INTx to Pull-up Input Mode 
	P4PH  |= 0x03;     //
	P2CON &= 0XFC;     //Set INTx to Pull-up Input Mode 
	P2PH  |= 0x03;     //
 
	//INT07:Rising edge interrupt / INT11/10:Falling edge interrupt / INT20/21:Double edge interrupt
  //Falling edge setting	
	INT0F = 0X00 ;    //xxxx 0000  0:Enable 1:Disable
	INT1F = 0X03 ;    //xxxx xxxx  0:Enable 1:Disable
  INT2F = 0X03 ;    //0000 xxxx  0:Enable 1:Disable
  //Rising edge setting
	INT0R = 0X80 ;    //xxxx 0000  0:Enable 1:Disable
	INT1R = 0X00 ;    //xxxx xxxx  0:Enable 1:Disable
	INT2R = 0X03 ;    //0000 xxxx  0:Enable 1:Disable
	
	//External interrupt priority setting
	IE  |= 0x05;	//0000 0x0x
	IE1 |= 0x08;	//0000 x000  Enable INT2
	IP  |= 0X00;
	IP1 |= 0X00;
	EA = 1;
}

/*****************************************************
*function: void EX0/1/2() interrupt	0/2/10  
*brief: Interrupt service function
*param: void
*retval: void
*****************************************************/
void EX0() interrupt	0
{
    P04 = ~P04;
}

void EX1() interrupt	2
{
    P05 = ~P05;
	if(P40 == 0)
	{
	    INT1_flag = 0x10; //INT10 generate interrupt
	}
	if(P41 == 0)
	{
	    INT1_flag = 0x20; //INT11 generate interrupt
	}
}

void EX2() interrupt	10
{
    P06 = ~P06;
}
