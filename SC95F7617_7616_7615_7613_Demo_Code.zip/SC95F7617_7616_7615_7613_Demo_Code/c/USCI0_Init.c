#include "H/Function_Init.H"

//Communication mode selection:
#define  Uart0   0
#define  TWI0    1
#define  SPI0    2


#define  USCI0_Mode  TWI0
#define TWI0_Mode 1//0:Master  1��Slaver
#define SPI0_Mode 1//0:Master 1��Slaver

void Uart0_Init(uint Freq,unsigned long int baud);
void TWI0_Init(void);
void SPI0_Init(void);

bit Uart0SendFlag = 0;    //Uart0 send interrupt flag
bit Uart0ReceiveFlag = 0; //Uart0 receive interrupt flag
bit SPI0Flag = 0;         //SPI0 interrupt flag
bit TWI0Flag = 0;         //TWI0 interrupt flag
uint8_t TxXferCount = 0; 
uint8_t RxXferCount = 0;  

volatile uint8_t Uart0_RxData[5];

uint8_t SPI0_Master_SendData[8] = {0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08};
volatile uint8_t SPI0_Slaver_ReceiveData[8];

uint8_t TWI0_Master_SendData[8]={0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08};
volatile uint8_t TWI0_Slaver_ReceiveData[8];
/*****************************************************
*function: void USCI0_Test(void)
*brief: Test USCI0
*param: void
*retval: void
*****************************************************/
void USCI0_Test(void)
{
#if (USCI0_Mode == Uart0)
	int num1,num2;
   Uart0_Init(32, 9600);
  while(1)
  {
		for(num1=0;num1<5;num1++)
		{
			while(!Uart0ReceiveFlag);
			Uart0ReceiveFlag = 0;
			Uart0_RxData[num1] = US0CON3 ;
		}
		for(num2=0;num2<5;num2++)
		{
			US0CON3  = Uart0_RxData[num2];
	  	while(!Uart0SendFlag);
      Uart0SendFlag = 0;
		}
  
  }
#endif
	
#if (USCI0_Mode == TWI0)
  TWI0_Init();
  while(1)
  {
#if (TWI0_Mode == 0)  //Master
      US0CON1 |= 0x20;    //Origin condition
		  Delay(100);
      while(TWI0Flag == 0);
      TWI0Flag = 0; 
      US0CON3 = 0x02;	    //Send address and write command
      while(TWI0Flag == 0);
      TWI0Flag = 0; 
      while(TxXferCount < 8)
			{
				US0CON3 = TWI0_Master_SendData[TxXferCount];     //TWI Send data
				while(TWI0Flag == 0);
				TWI0Flag = 0; 
			  TxXferCount++;
			}
     TxXferCount=0;

    /* Whether the transmission is complete or not, the end signal needs to be sent to prevent the host from occupying the bus */
      US0CON1 |= 0x10;
	
			Delay(1000);
#endif   
#if (TWI0_Mode == 1)  //Slaver  

			while((0x07 & US0CON0)!=0x02);//Check that the status is received
			Delay(100);
			while(TWI0Flag == 0);
			TWI0Flag = 0;                 
     	Delay(100);
    /* Receiving data procedure */
			do
			{
				if(RxXferCount == 7) US0CON0 &= 0XF7;   //AA enable bit, return to the UAC of the host
				while(TWI0Flag == 0);
				TWI0Flag = 0;  
				TWI0_Slaver_ReceiveData[RxXferCount] = US0CON3;             //TWI Received data
				RxXferCount++; 
			}  while(RxXferCount < 8);

			US0CON0 |= 0X08; //AA Enable bit
			RxXferCount =0;
			while((0x07 & US0CON0)!=0x00);
		 
		
#endif
  }
#endif

#if (USCI0_Mode == SPI0)
   SPI0_Init();
   
   while(1)
   { 
#if (SPI0_Mode == 0)  //Master
	    TxXferCount = 0;
			while(TxXferCount <  8)//Determines whether to accept all data
			{
			 
				US0CON2 = SPI0_Master_SendData[TxXferCount];
				while(SPI0Flag == 0);	//	Wait for sending to complete	   
				SPI0Flag = 0;		
				TxXferCount ++;	
			
			}
	   	Delay(1000);
		

#elif (SPI0_Mode == 1) //Slaver
   
 
			 while(RxXferCount <8)
				{
					/* Wait for the SPI interrupt flag position to start */
					while(SPI0Flag == 0);	//Wait for sending to complete
					SPI0Flag = 0;		
					SPI0_Slaver_ReceiveData[RxXferCount] = US0CON2;			
					RxXferCount++;	       
				}
				RxXferCount = 0;
			  Delay(100);
#endif
  }
#endif
}
/*****************************************************
*function: void Uart0_Init(uint Freq,unsigned long int baud)
*brief: Uart0 initialization
*param1: Freq
*param2: baud
*retval: void
*****************************************************/
void Uart0_Init(uint Freq,unsigned long int baud)
{
	P0CON &= 0x9F;    //TX/RX is set to pull-up Input Mode 
	P0PH  |= 0x60;
	
	OTCON |= 0x30;    //USCI0 Serial interface select UART mode
	US0CON0 = 0x50;   //Set the communication mode to mode 1 and allow receiving
	US0CON1 = Freq*1000000/baud;   
	US0CON2 = (Freq*1000000/baud)>>8;   
	IE1 |= 0x01;      //Enable USCI0 interrupt
  EA = 1;	
}

/*****************************************************
*function: void TWI0_Init(void)
*brief: TWI0 initialization
*param: void
*retval: void
*****************************************************/
void TWI0_Init(void)
{
	OTCON |= 0x20;   //USCI0 Serial interface select TWI mode
  US0CON0 = 0x88;  // The reply flag bit was enabled
  US0CON1 = 0x40;  //---- xxxx  x is Clock rate
  US0CON2 = 0x02;  //Slave address 0x01
	IE1 |= 0x01;
	EA = 1;
}

/*****************************************************
*function: void SPI0_Init(void)
*brief: SPI0 initialization
*param: void
*retval: void
*****************************************************/
void SPI0_Init(void)
{
	OTCON |= 0X10;    //USCI0 Serial interface select SPI mode
#if (SPI0_Mode == 0)	
 {  US0CON0 = 0x23;   }   //Set SPI0 as the master, SCK to low level, SCK cycle first edge to collect data, the clock rate to Fsy/8
#elif (SPI0_Mode == 1)	
 {  US0CON0 = 0x03;   }   //Set SPI0 to slave , SCK idle time to low, SCK cycle first edge to collect data,the clock rate to Fsy/8
#endif 
	US0CON1 = 0x00;   //MSB is sent first.  8-bit mode
	US0CON0 |= 0x80;  //Enable SPI0
	IE1 |= 0x01;
	EA = 1;
}

/*****************************************************
*function: void TWI0/SPI/UART0_Int() interrupt 7
*brief: Interrupt service function
*param: void
*retval: void
*****************************************************/
#if (USCI0_Mode == Uart0)
void Uart0_Int() interrupt 7   //Uart0 interrupt service function
{
	if(US0CON0&0x02)    //Judge send flag
	{
		US0CON0 &= 0xFD;
		Uart0SendFlag = 1;
	}
	if((US0CON0&0x01))  //Judge receive flag
	{
		US0CON0 &= 0xFE;
		Uart0ReceiveFlag = 1;
	}	
}
#endif

#if (USCI0_Mode == TWI0)
void TWI0_Int() interrupt 7     //TWI0 interrupt service function
{
	if(US0CON0&0x40)
	{
		US0CON0 &= 0xbf;  //Clear interrupt flag
		TWI0Flag = 1;
	}	
}
#endif 

#if (USCI0_Mode == SPI0)
void Spi0Int(void) interrupt 7    //SPI0 interrupt service function
{	  
	if(US0CON1&0X80)    //Judge data transmiUSCIon flag
	{
		US0CON1 &= ~0X80;
		SPI0Flag = 1;
	}
}
#endif 