#include "H/Function_Init.H" 

void CMP_Init(uchar CMPIS, uchar CMPRF);

/*************Analog comparator negative terminal comparison voltage selection****************/
enum CMPRF {CMPRF=0,CMPRF1,CMPRF2,CMPRF3,CMPRF4,CMPRF5,CMPRF6,CMPRF7,CMPRF8,CMPRF9,CMPRF10,CMPRF11,CMPRF12,CMPRF13,CMPRF14,CMPRF15};

/*************Analog comparator positive terminal input channel selection****************/
enum CMPIS {CMP0=0,CMP1,CMP2,CMP3};

bit CMPSTA = 0;

/*****************************************************
*function: void CMP_Test(void)
*brief: Test CMP
*param: void
*retval: void
*****************************************************/
void CMP_Test(void)
{
	CMP_Init(CMP1,CMPRF8);  //Select positive channel CMP1, Select the negative voltage 1/16VDD
	while(1)
	{
    P04 = ~P04;
		if(CMPCON&0x20)     //Judgment analog comparator interrupt flag
		{
			CMPSTA = 1;     //V+ > V-
		}
		else
		{
			CMPSTA = 0;     //V- > V+
		}
	}
}

/*****************************************************
*function: void CMP_Init(uchar CMPIS, uchar CMPRF)
*brief: CMP initialization
*param1: CMPIS-positive terminal input channel
*param2: CMPRF-negative terminal comparison voltage
*retval: void
*****************************************************/
void CMP_Init(uchar CMPIS, uchar CMPRF)
{
	CMPCON = 0x80;   //Enable analog comparator
	CMPCON |= CMPRF; //Negative terminal comparison voltage selection
	CMPCFG = 0x04;   //Rising edge interrupt
	CMPCFG |= CMPIS; //Positive terminal input channel selection
    
    IE1 |= 0x20;
    EA = 1;
}

void CMP_INTERRUPT() interrupt 12
{
	CMPCON &= ~0x40;	//Clear the interrupt flag
    P05 = ~P05;
}