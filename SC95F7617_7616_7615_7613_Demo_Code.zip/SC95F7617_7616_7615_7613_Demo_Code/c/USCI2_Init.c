#include "H/Function_Init.H"

//Communication mode selection:
#define  Uart2   0
#define  TWI2    1
#define  SPI2    2

#define  USCI2_Mode  TWI2
#define TWI2_Mode 0//0:Master  1��Slaver
#define SPI2_Mode 0 //0:Master  1��Slaver

void Uart2_Init(uint Freq,unsigned long int baud);
void TWI2_Init(void);
void SPI2_Init(void);

bit Uart2SendFlag = 0;    //Uart2 send interrupt flag
bit Uart2ReceiveFlag = 0; //Uart2 receive interrupt flag
bit SPI2Flag = 0;         //SPI2 data transfer completion flag 
bit TWI2Flag = 0;         //TWI2 interrupt flag

uint8_t TxXferCount2 = 0;  //SPI/TWI����������Ŀ
uint8_t RxXferCount2 = 0;  //SPI/TWI����������Ŀ 
volatile uint8_t Uart2_RxData[5];
uint8_t SPI2_Master_SendData[8] = {0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08};
volatile uint8_t SPI2_Master_ReceiveData[8];
uint8_t SPI2_Slaver_SendData[8] = {0x08,0x09,0x0A,0x0B,0x0C,0x0D,0x0E,0x0F};
volatile uint8_t SPI2_Slaver_ReceiveData[8];

uint8_t TWI2_Master_SendData[8]={0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08};
volatile uint8_t TWI2_Master_ReceiveData[8];
uint8_t TWI2_Slaver_SendData[8]={0x08,0x09,0x0A,0x0B,0x0C,0x0D,0x0E,0x0F};
volatile uint8_t TWI2_Slaver_ReceiveData[8];
/*****************************************************
*function: void USCI2_Test(void)
*brief: Test USCI2
*param: void
*retval: void
*****************************************************/
void USCI2_Test(void)
{
#if (USCI2_Mode == Uart2)
	int num1,num2;
	Uart2_Init(32,9600);
	while(1)
	{
		   for(num1=0;num1<5;num1++)
		{
			while(!Uart2ReceiveFlag);
			Uart2ReceiveFlag = 0;
			Uart2_RxData[num1] = US2CON3 ;
		}
		for(num2=0;num2<5;num2++)
		{
			US2CON3  = Uart2_RxData[num2];
		  	while(!Uart2SendFlag);
		    Uart2SendFlag = 0;
    }
	}
#endif
	
#if (USCI2_Mode == TWI2)
	TWI2_Init();
	while(1)
	{
		#if (TWI2_Mode == 0)  //Master
			{
				US2CON1 |= 0x20;    //Origin condition
				Delay(100);
				while(TWI2Flag == 0);
				TWI2Flag = 0; 
				US2CON3 = 0x02|0X01;	    //Send address and write command
				Delay(100);
				while(TWI2Flag == 0);
				TWI2Flag = 0; 

		/* Received data */
				do
				{
						if(RxXferCount2 ==7)
					{
							US2CON0 &= 0XF7;    	
					}
				
					 while(TWI2Flag == 0);
					 TWI2Flag = 0; 
					 TWI2_Master_ReceiveData[RxXferCount2] = US2CON3;    //TWI Received data
					 RxXferCount2++;	
				}
				while(RxXferCount2 < 8);
			
			 RxXferCount2=0;
				/* Whether the transmission is complete or not, the end signal needs to be sent to prevent the host from occupying the bus */
			 US2CON0 |= 0X08; //AA enable bit, return to the UAC of the host
			 US2CON1 |= 0x10;
			 Delay(500);
			}
	#endif
	#if (TWI2_Mode == 1)  //Slaver 
		 {  
			  
		 TWI2Flag = 0; 
			 while((0x07 & US2CON0)!=0x00);//Check whether the status returns to idle
			 
			  while((0x07 & US2CON0)!=0x03);//Status Indicates whether the status is sent
			  while(TWI2Flag == 0);
			 TWI2Flag = 0; 
			TxXferCount2=0;
			 while(TxXferCount2 < 8)
			 {

				US2CON3 = TWI2_Slaver_SendData[TxXferCount2];             //TWI Send data
				while(TWI2Flag == 0);
				TWI2Flag = 0; 
				TxXferCount2++;

			 }
				US2CON3 = TWI2_Slaver_SendData[0];
			 
			 while((0x07 & US2CON0)!=0x00);//Check whether the status returns to idle

				TxXferCount2=0;
				Delay(100);
			 }
	#endif
	}
#endif

#if (USCI2_Mode == SPI2)
	SPI2_Init();
	while(1)
	{
		#if (SPI2_Mode == 0)  //Master
	   TxXferCount2 = 0;
    while(TxXferCount2 <  8)//Determines whether to accept all data
    {
     
      US2CON2 = SPI2_Master_SendData[TxXferCount2];
      

      while(SPI2Flag == 0);	//Wait for sending to complete
		 
      SPI2Flag = 0;		
      SPI2_Master_ReceiveData[TxXferCount2]=US2CON2;
      TxXferCount2 ++;	
    
		}
		Delay(1000);;
		

     #elif (SPI2_Mode == 1) //Slaver
 
 
	   while(RxXferCount2 <8)
    {
			 US2CON2=SPI2_Slaver_SendData[RxXferCount2];
      /* Wait for the SPI interrupt flag position to start */
      
			while(SPI2Flag == 0);	//Wait for sending to complete
		   
      SPI2Flag = 0;		
      SPI2_Slaver_ReceiveData[RxXferCount2] = US2CON2;		
      RxXferCount2++;	
      
      }
		 Delay(100);
	  RxXferCount2 = 0;
		
     #endif
	}
#endif	
}
/*****************************************************
*function: void Uart2_Init(uint Freq,unsigned long int baud)
*brief: Uart2 initialization
*param1: Freq
*param2: baud
*retval: void
*****************************************************/
void Uart2_Init(uint Freq,unsigned long int baud)
{
	P4CON &= 0xCF;    //TX/RX is set to pull-up Input Mode 
	P4PH  |= 0x30;
	
	TMCON |= 0xC0;    //USCI2 Serial interface select UART mode
	US2CON0 = 0x50;   //Set the communication mode to mode 1 and allow receiving
	US2CON1 = Freq*1000000/baud;   
	US2CON2 = (Freq*1000000/baud)>>8;   
	IE2 |= 0x02;      //Enable USCI0 interrupt
    EA = 1;	
}

/*****************************************************
*function: void TWI2_Init(void)
*brief: TWI2 initialization
*param: void
*retval: void
*****************************************************/
void TWI2_Init(void)
{
	#if (TWI2_Mode == 0)	
 { US2CON3 = TWI2_Slaver_SendData[0];   }   //Prepare data from the slave machine in advance
#endif
	TMCON |= 0x80;   //USCI2 Serial interface select TWI mode
	US2CON0 = 0x88;  //The reply flag bit was enabled
	US2CON1 = 0x40;  //---- xxxx  x is Clock rate
    US2CON2 = 0x02;  //Slave address 0x01
	IE2 |= 0x02;
	EA = 1;
}

/*****************************************************
*function: void SPI2_Init(void)
*brief: SPI2 initialization
*param: void
*retval: void
*****************************************************/
void SPI2_Init(void)
{
	TMCON |= 0X40;    //USCI2 Serial interface select SPI mode
#if (SPI2_Mode == 0)	
 {  US2CON0 = 0x23;   }   //Set SPI1 as the master, SCK to low level, SCK cycle first edge to collect data, the clock rate to Fsy/8
#elif (SPI2_Mode == 1)	
 {  US2CON0 = 0x03; }   //Set SPI0 to slave , SCK idle time to low, SCK cycle first edge to collect data,the clock rate to Fsy/8
#endif 
	US2CON1 = 0x01;   //MSB is sent first.  8-bit mode
	US2CON0 |= 0x80;  //Enable SPI1
	IE2 |= 0x02;
	EA = 1;
}

/*****************************************************
*function: void TWI1/SPI/UART1_Int() interrupt 7
*brief: Interrupt service function
*param: void
*retval: void
*****************************************************/
#if (USCI2_Mode == Uart2)
void Uart2_Int() interrupt 16   //Uart2 interrupt service function
{
	if(US2CON0&0x02)    //Judge send flag
	{
		US2CON0 &= 0xFD;
		Uart2SendFlag = 1;
	}
	if((US2CON0&0x01))  //Judge receive flag
	{
		US2CON0 &= 0xFE;
		Uart2ReceiveFlag = 1;
	}	
}
#endif

#if (USCI2_Mode == TWI2)
void TWI2_Int() interrupt 16     //TWI2 interrupt service function
{
	if(US2CON0&0x40)
	{
		US2CON0 &= 0xbf;  //Clear interrupt flag
		TWI2Flag = 1;
	}	
}
#endif 

#if (USCI2_Mode == SPI2)
void Spi2Int(void) interrupt 16    //SPI2 interrupt service function
{	  
	if(US2CON1&0X08)    //Send register empty flag judgment
	{
		US2CON1 &= ~0X08;
	}
	if(US2CON1&0X80)    //Judge data transmiUSCIon flag
	{
		US2CON1 &= ~0X80;
		SPI2Flag = 1;
	}
}
#endif 