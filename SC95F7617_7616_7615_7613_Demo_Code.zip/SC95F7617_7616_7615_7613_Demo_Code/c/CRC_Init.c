#include "H/Function_Init.H"

char Array[] = {0x00,0x11,0x22,0x33,0x44,0x55,0x66,0x77,0x88,0x99,0xaa,0xbb,0xcc,0xdd,0xee,0xff};
typedef struct
{
    char a3;        //High address
    char a2;        //Subhigh address
    char a1;        //Sublow address
    char a0;        //Low address
}Value_Typedef;    
typedef union
{
    Value_Typedef reg; 
    unsigned long int result;   //The calculation results
}Result_Typedef;

unsigned long int temp = 0x00;  //Store the calculation results
Result_Typedef CRC_Result;

void CRC_Hardware_Init(void);
void CRC_Software_Init(char array[]);

/*****************************************************
*function: void CRC_Test(void)
*brief: Test CEC
*param: void
*retval: void
*****************************************************/
void CRC_Test(void)
{
    //Hardware validation
    CRC_Hardware_Init();
    //Software validation
    CRC_Software_Init(Array);
}

/*****************************************************
*function: void CRC_Hardware_Init(void)
*brief: Hardware validation initialization
*param: void
*retval: void
*****************************************************/
void CRC_Hardware_Init(void)
{
    bit EABIT = EA;
    EA = 0;
    OPERCON |= 0x01;  //Start Hardware verification
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
  _nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();

    CRCINX = 0x00;
    CRC_Result.reg.a0 = CRCREG;   //Two bytes lower result
    CRC_Result.reg.a1 = CRCREG;   //Second low two byte result
    CRC_Result.reg.a2 = CRCREG;   //Second higher two byte result
    CRC_Result.reg.a3 = CRCREG;   //Two bytes higher result
    temp = CRC_Result.result;     //Get the final result
    EA = EABIT;
}

/*****************************************************
*function: void CRC_Hardware_Init(void)
*brief: Software validation initialization
*param: void
*retval: void
*****************************************************/
void CRC_Software_Init(char array[])
{
    int i = 0;
    bit EABIT = EA;
    EA = 0;
    OPERCON |= 0x02;         //Start software verification
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
  _nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
    for(i=0; i<16; i++)      //Check range
    {
        CRCREG = array[i];   //Calculated value
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
  _nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();
	_nop_();         
    }
    CRCINX = 0x00;
    CRC_Result.reg.a0 = CRCREG;   //Two bytes lower result
    CRC_Result.reg.a1 = CRCREG;   //Second low two byte result
    CRC_Result.reg.a2 = CRCREG;   //Second higher two byte result
    CRC_Result.reg.a3 = CRCREG;   //Two bytes higher result
    temp = CRC_Result.result;     //Get the final result
    EA = EABIT;
}